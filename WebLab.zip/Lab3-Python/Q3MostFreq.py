from collections import Counter
import re

def get_most_frequent_words(file_path, num_words=10):
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read().lower()
    # Use regex to find words
    words = re.findall(r'\b\w+\b', text)
    # Count the frequency of each word
    word_counts = Counter(words)
    # Get the most common words
    most_common_words = word_counts.most_common(num_words)
    return most_common_words
if __name__ == "__main__":
    file_path = 'Lab4-Python/input.txt'
    most_frequent_words = get_most_frequent_words(file_path)
    for word, frequency in most_frequent_words:
        print(f'{word}: {frequency}')